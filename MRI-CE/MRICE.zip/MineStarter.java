import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URL;

public class MineStarter {
    public static void main(String[] args) throws IOException {
        String input=fileToPath("input.txt");
        String output=".//output.txt";
        final double min_sup_percentage = 0.5;
        MRICE excutor = new MRICE();
        excutor.runAlgorithm(input,output,min_sup_percentage);
        excutor.printStats();
    }
    public static String fileToPath(String filename) throws UnsupportedEncodingException {
        URL url=MineStarter.class.getResource((filename));
        return java.net.URLDecoder.decode(url.getPath(),"UTF-8");
    }
}
